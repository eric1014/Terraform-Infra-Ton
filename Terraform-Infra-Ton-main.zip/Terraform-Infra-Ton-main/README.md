# Terraform  -  Desafio - Infra-as-code - Devops (TON)


Repositório com os arquivos do post https://github.com/eric1014/Terraform-Infra-Ton
